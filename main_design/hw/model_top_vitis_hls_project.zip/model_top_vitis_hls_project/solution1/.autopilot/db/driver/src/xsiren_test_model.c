// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2023 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsiren_test_model.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSiren_test_model_CfgInitialize(XSiren_test_model *InstancePtr, XSiren_test_model_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSiren_test_model_Start(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSiren_test_model_IsDone(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSiren_test_model_IsIdle(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSiren_test_model_IsReady(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSiren_test_model_Continue(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XSiren_test_model_EnableAutoRestart(XSiren_test_model *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSiren_test_model_DisableAutoRestart(XSiren_test_model *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XSiren_test_model_Set_x_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_x_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_x_out(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_OUT_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_x_out(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_OUT_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_X_OUT_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_load_parameters_flag(XSiren_test_model *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_LOAD_PARAMETERS_FLAG_DATA, Data);
}

u32 XSiren_test_model_Get_load_parameters_flag(XSiren_test_model *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_LOAD_PARAMETERS_FLAG_DATA);
    return Data;
}

void XSiren_test_model_Set_input_layer_weight_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_WEIGHT_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_WEIGHT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_input_layer_weight_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_WEIGHT_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_WEIGHT_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_input_layer_bias_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_BIAS_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_BIAS_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_input_layer_bias_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_BIAS_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_BIAS_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_input_layer_w0_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_W0_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_W0_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_input_layer_w0_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_W0_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_INPUT_LAYER_W0_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_hidden_layers_weight_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_WEIGHT_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_WEIGHT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_hidden_layers_weight_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_WEIGHT_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_WEIGHT_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_hidden_layers_bias_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_BIAS_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_BIAS_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_hidden_layers_bias_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_BIAS_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_BIAS_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_hidden_layers_w0_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_W0_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_W0_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_hidden_layers_w0_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_W0_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_HIDDEN_LAYERS_W0_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_output_layer_weight_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_WEIGHT_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_WEIGHT_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_output_layer_weight_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_WEIGHT_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_WEIGHT_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_Set_output_layer_bias_in(XSiren_test_model *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_BIAS_IN_DATA, (u32)(Data));
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_BIAS_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XSiren_test_model_Get_output_layer_bias_in(XSiren_test_model *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_BIAS_IN_DATA);
    Data += (u64)XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_OUTPUT_LAYER_BIAS_IN_DATA + 4) << 32;
    return Data;
}

void XSiren_test_model_InterruptGlobalEnable(XSiren_test_model *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_GIE, 1);
}

void XSiren_test_model_InterruptGlobalDisable(XSiren_test_model *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_GIE, 0);
}

void XSiren_test_model_InterruptEnable(XSiren_test_model *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_IER);
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_IER, Register | Mask);
}

void XSiren_test_model_InterruptDisable(XSiren_test_model *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_IER);
    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSiren_test_model_InterruptClear(XSiren_test_model *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSiren_test_model_WriteReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_ISR, Mask);
}

u32 XSiren_test_model_InterruptGetEnabled(XSiren_test_model *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_IER);
}

u32 XSiren_test_model_InterruptGetStatus(XSiren_test_model *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSiren_test_model_ReadReg(InstancePtr->Control_BaseAddress, XSIREN_TEST_MODEL_CONTROL_ADDR_ISR);
}

