// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 4  - ap_continue (Read/Write/SC)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of x_in
//        bit 31~0 - x_in[31:0] (Read/Write)
// 0x14 : Data signal of x_in
//        bit 31~0 - x_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of x_out
//        bit 31~0 - x_out[31:0] (Read/Write)
// 0x20 : Data signal of x_out
//        bit 31~0 - x_out[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of load_parameters_flag
//        bit 31~0 - load_parameters_flag[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of input_layer_weight_in
//        bit 31~0 - input_layer_weight_in[31:0] (Read/Write)
// 0x34 : Data signal of input_layer_weight_in
//        bit 31~0 - input_layer_weight_in[63:32] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of input_layer_bias_in
//        bit 31~0 - input_layer_bias_in[31:0] (Read/Write)
// 0x40 : Data signal of input_layer_bias_in
//        bit 31~0 - input_layer_bias_in[63:32] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of input_layer_w0_in
//        bit 31~0 - input_layer_w0_in[31:0] (Read/Write)
// 0x4c : Data signal of input_layer_w0_in
//        bit 31~0 - input_layer_w0_in[63:32] (Read/Write)
// 0x50 : reserved
// 0x54 : Data signal of hidden_layers_weight_in
//        bit 31~0 - hidden_layers_weight_in[31:0] (Read/Write)
// 0x58 : Data signal of hidden_layers_weight_in
//        bit 31~0 - hidden_layers_weight_in[63:32] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of hidden_layers_bias_in
//        bit 31~0 - hidden_layers_bias_in[31:0] (Read/Write)
// 0x64 : Data signal of hidden_layers_bias_in
//        bit 31~0 - hidden_layers_bias_in[63:32] (Read/Write)
// 0x68 : reserved
// 0x6c : Data signal of hidden_layers_w0_in
//        bit 31~0 - hidden_layers_w0_in[31:0] (Read/Write)
// 0x70 : Data signal of hidden_layers_w0_in
//        bit 31~0 - hidden_layers_w0_in[63:32] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of output_layer_weight_in
//        bit 31~0 - output_layer_weight_in[31:0] (Read/Write)
// 0x7c : Data signal of output_layer_weight_in
//        bit 31~0 - output_layer_weight_in[63:32] (Read/Write)
// 0x80 : reserved
// 0x84 : Data signal of output_layer_bias_in
//        bit 31~0 - output_layer_bias_in[31:0] (Read/Write)
// 0x88 : Data signal of output_layer_bias_in
//        bit 31~0 - output_layer_bias_in[63:32] (Read/Write)
// 0x8c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define CONTROL_ADDR_AP_CTRL                      0x00
#define CONTROL_ADDR_GIE                          0x04
#define CONTROL_ADDR_IER                          0x08
#define CONTROL_ADDR_ISR                          0x0c
#define CONTROL_ADDR_X_IN_DATA                    0x10
#define CONTROL_BITS_X_IN_DATA                    64
#define CONTROL_ADDR_X_OUT_DATA                   0x1c
#define CONTROL_BITS_X_OUT_DATA                   64
#define CONTROL_ADDR_LOAD_PARAMETERS_FLAG_DATA    0x28
#define CONTROL_BITS_LOAD_PARAMETERS_FLAG_DATA    32
#define CONTROL_ADDR_INPUT_LAYER_WEIGHT_IN_DATA   0x30
#define CONTROL_BITS_INPUT_LAYER_WEIGHT_IN_DATA   64
#define CONTROL_ADDR_INPUT_LAYER_BIAS_IN_DATA     0x3c
#define CONTROL_BITS_INPUT_LAYER_BIAS_IN_DATA     64
#define CONTROL_ADDR_INPUT_LAYER_W0_IN_DATA       0x48
#define CONTROL_BITS_INPUT_LAYER_W0_IN_DATA       64
#define CONTROL_ADDR_HIDDEN_LAYERS_WEIGHT_IN_DATA 0x54
#define CONTROL_BITS_HIDDEN_LAYERS_WEIGHT_IN_DATA 64
#define CONTROL_ADDR_HIDDEN_LAYERS_BIAS_IN_DATA   0x60
#define CONTROL_BITS_HIDDEN_LAYERS_BIAS_IN_DATA   64
#define CONTROL_ADDR_HIDDEN_LAYERS_W0_IN_DATA     0x6c
#define CONTROL_BITS_HIDDEN_LAYERS_W0_IN_DATA     64
#define CONTROL_ADDR_OUTPUT_LAYER_WEIGHT_IN_DATA  0x78
#define CONTROL_BITS_OUTPUT_LAYER_WEIGHT_IN_DATA  64
#define CONTROL_ADDR_OUTPUT_LAYER_BIAS_IN_DATA    0x84
#define CONTROL_BITS_OUTPUT_LAYER_BIAS_IN_DATA    64
